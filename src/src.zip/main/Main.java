package main;
import java.io.*;
import lexer.*;
public class Main {
	public static void main(String[] args) throws IOException
	{
/*		char peek=' ';
		int line=1;
		File f=new File("E:/test.cpp");
    	FileInputStream file = new FileInputStream(f);
    	StringBuffer sb=new StringBuffer();
    	int size;
    	try {
    		size = file.available();					
    		System.out.println("�ɶ�ȡ���ֽ��� " + size);	
    		char [] text = new char[size];					
    		for (int i = 0; i < text.length; i++) 
    		{	
    			text[i] = ((char)file.read());						
    			System.out.print(text[i]);					
    			}
    		System.out.println((int)'\n');
    		for(int i = 0; i < text.length; i++)
        	{
        		peek=text[i];
        		if(peek==' '||peek=='\t'||peek=='\n') continue;
        		else if((int)peek!=13)  System.out.print(text[i]);
        	}
    		} catch (IOException e) {
    			// TODO Auto-generated catch block					
    			e.printStackTrace();				
    		}*/
/*		RandomAccessFile n=new RandomAccessFile("E:/test.cpp","rw");
		n.seek(132);
		System.out.println((char)n.read());
*/
		
		String path="C:\\\\Users\\\\Mac\\\\Desktop\\\\123.txt";
		new FileWriter(path);
		Lexer lex=new Lexer();
        lex.scan(path);
    	

	}		
}